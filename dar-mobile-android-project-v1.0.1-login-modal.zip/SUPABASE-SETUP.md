# إعداد Supabase لتطبيق دار

1. افتح مشروع Supabase ثم SQL Editor.
2. نفّذ كامل الملف `supabase-schema.sql`.
3. أنشئ حسابًا من التطبيق باستخدام البريد الإلكتروني.
4. من SQL Editor عيّن حسابك مديرًا:

```sql
update public.profiles
set role = 'admin'
where email = 'your-email@example.com';
```

5. سجّل الخروج من التطبيق ثم سجّل الدخول مرة أخرى.

مفتاح `publishable` يمكن تضمينه في تطبيق الهاتف. لا تضع أبدًا `service_role` أو كلمة مرور Supabase داخل التطبيق أو المستودع.
