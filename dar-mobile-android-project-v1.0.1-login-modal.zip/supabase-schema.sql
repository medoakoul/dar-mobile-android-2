-- دار: مخطط المستخدمين والصلاحيات المركزي
-- شغّل هذا الملف في Supabase SQL Editor قبل استخدام التسجيل المركزي.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  name text not null,
  phone text,
  role text not null default 'seeker' check (role in ('admin','broker','seeker')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin' and active=true); $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id,email,name,phone,role)
  values(new.id,new.email,coalesce(new.raw_user_meta_data->>'name',new.email),new.raw_user_meta_data->>'phone',case when new.raw_user_meta_data->>'role'='broker' then 'broker' else 'seeker' end)
  on conflict (id) do update set email=excluded.email,name=excluded.name,phone=excluded.phone;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

drop policy if exists profiles_select_self_or_admin on public.profiles;
create policy profiles_select_self_or_admin on public.profiles for select to authenticated
using (id=auth.uid() or public.is_admin());

drop policy if exists profiles_update_admin on public.profiles;
create policy profiles_update_admin on public.profiles for update to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists profiles_insert_admin on public.profiles;
create policy profiles_insert_admin on public.profiles for insert to authenticated
with check (public.is_admin());

-- بعد إنشاء حسابك الأول، عيّنه مديرًا باستبدال البريد:
-- update public.profiles set role='admin' where email='your-email@example.com';
